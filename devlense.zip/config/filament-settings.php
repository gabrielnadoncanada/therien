<?php

return [
    // Group the menu item belongs to
    'group' => 'Settings',

    // Sidebar label
    'label' => 'Settings',

    // Page title
    'title' => 'Settings',

    // Path to the file to be used as storage
    'path' => storage_path('app/settings.json'),
];
