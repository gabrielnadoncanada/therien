<input type="checkbox" {{ $controlAttributes() }}  value="{{ $value }}" {{ $checked ? 'checked' : '' }}>
