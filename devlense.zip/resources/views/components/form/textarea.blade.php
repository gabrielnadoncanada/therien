<textarea {{ $controlAttributes() }}>{{ $value ?? $slot }}</textarea>
