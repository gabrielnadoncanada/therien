<span {{ $attributes->merge(['class' => $theme()]) }}>{{ $slot }}</span>
