
<li {{ $attributes->merge(['class' => $theme()])}}>
	<a class="flex items-center" href="{{ Route::has($route) ? route($route) : ''}}" >{{ $slot }}</a>
</li>
