@php
    $projects = [
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
        [
            'before_url' => '/images/image 3.png',
            'after_url' => '/images/image 3.png',
        ],
    ];

@endphp

<section {{ $attributes }}>
    <div class="mx-auto max-w-[1500px] px-6">
        <div class="grid grid-cols-1 xl:grid-cols-2 gap-[50px] xl:gap-[174px]">
            <div class="flex-1">
                <div class="mx-auto  lg:mx-0  flex flex-col gap-y-[61px]">
                    <x-text as="h2" theme="h1" class="text-primary">Nous n’avons qu’un but,
                        <span class="text-white block">le vôtre.</span>
                    </x-text>
                    <div class="flex flex-col gap-y-6">
                        <x-text theme="invert">Nous vous offrons bien plus qu'une simple prestations.</x-text>
                        <x-text theme="invert">Nous créons des expériences captivantes pour vos espaces extérieurs. Chaque projet
                            devient
                            une toile où notre créativité audacieuse et notre expertise technique se conjuguent pour
                            donner vie à des environnements uniques.
                        </x-text>
                        <x-text theme="invert">Votre espace devient une expression de notre passion, où l'innovation rencontre
                            l'élégance
                            pour créer une expérience visuelle inoubliable.
                        </x-text>
                    </div>
                    <x-button theme="large" class="mr-auto">Ca m’intéresse</x-button>
                </div>
            </div>
            <div class="flex-1 hidden xl:block">
                <div class="relative  sm:mx-auto  sm:rounded-3xl  sm:pr-0 lg:mx-0 ">
                    <div x-data="{ swiper: null }" x-init="swiper = new Swiper($refs.container, {
 spaceBetween: 30,
	pagination: {
		el: '.swiper-pagination',
		clickable: true,
	},
                    })">
                        <img class="absolute top-[-45px] right-[-154px] z-[20]" src="{{ asset('/svg/paint.svg') }}"
                             alt="">
                        <div x-ref="container" class="swiper-container overflow-hidden">
                            <div class="swiper-wrapper">
                                @foreach ($projects as $index => $project)
                                    <div class="swiper-slide">
                                        <img src="{{ asset($project['before_url']) }}" alt="Product screenshot"
                                             class="  aspect-[700/880] object-cover rounded-[50px] ">
                                    </div>
                                @endforeach
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=" hidden xl:flex justify-center -mt-8">
            <img src="{{ asset('images/blocks.svg') }}" alt="" width="300">
        </div>
    </div>
</section>
