<div>
	{{$post->title}}
</div>