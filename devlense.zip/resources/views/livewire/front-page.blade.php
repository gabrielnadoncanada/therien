<div>


    <x-sections.site.hero></x-sections.site.hero>
    <x-sections.site.projects class="mt-20 lg:mt-44"></x-sections.site.projects>
    <x-sections.site.services-banner :services="$services"></x-sections.site.services-banner>
    <x-sections.site.services class="mt-20 lg:mt-64 relative" ></x-sections.site.services>
    <x-sections.site.testimonials class="relative lg:mt-96" ></x-sections.site.testimonials>
    <x-sections.site.partners class="lg:mt-48 max-w-[1600px] mx-auto text-center" ></x-sections.site.partners>



</div>

