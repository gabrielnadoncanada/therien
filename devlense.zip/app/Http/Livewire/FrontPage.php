<?php

namespace App\Http\Livewire;

use App\Repositories\ServiceRepository;
use App\Repositories\PartnerRepository;
use App\Repositories\TestimonialRepository;
use Livewire\Component;

class FrontPage extends Component
{
    private $services;
    private $partners;
    private $testimonials;

    public function mount(ServiceRepository $serviceRepository, PartnerRepository $partnerRepository, TestimonialRepository $testimonialRepository)
    {
        $this->services = $serviceRepository->getAllSorted();
        $this->partners = $partnerRepository->getAllSorted();
        $this->testimonials = $testimonialRepository->getAllSorted();
    }

    public function render()
    {
        return view('livewire.front-page', [
            'services' => $this->services,
            'partners' => $this->partners,
            'testimonials' => $this->testimonials,
        ]);
    }
}
